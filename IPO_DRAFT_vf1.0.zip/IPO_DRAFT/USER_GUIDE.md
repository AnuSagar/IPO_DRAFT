# IPO Drafting Assistant – User Guide

This guide is for anyone using the tool for the first time. It explains the whole process from start to finish. You don't need to know any programming.

---

## 1. What the tool does

The tool helps you write the first draft of two DRHP sections for an Indian IPO:
- **Our Business**
- **Risk Factors**

The work is split in two:

| Who | Does what |
|---|---|
| **The tool (Python, on your machine)** | Reads the PDFs, finds the right sections and pages, pulls out the key figures, and prepares small "packs" of pages. It then checks the draft that comes back. |
| **Stylus Workspace (Citi GenAI)** | Writes the text, using the pack you upload to it. |
| **You (the banker)** | Upload the documents, review what the tool found, move packs between the tool and Stylus, and edit and approve the final text. |

Every fact in the draft carries a page citation such as **[D1 p.145]**, so you can always check where it came from.

---

## 2. Two kinds of documents

| Kind | Examples | Label | Used for |
|---|---|---|---|
| **Company documents** | Annual report, audited financials, investor presentation, management notes | **D1, D2, …** | **Facts.** These are the only source of numbers and statements. |
| **Comparable prospectuses** | DRHPs/RHPs of similar listed companies | **C1, C2, …** | **Style and structure only.** No facts are ever taken from them. |

Citation labels:
- `[D1 p.145]`: company document D1, printed page 145. This is the page number printed on the page, not the PDF page number.
- `[C2 p.170]`: comparable C2, page 170. This appears only as a style example, never as a source of a fact.

---

## 3. The process at a glance

```
1 Deal Setup  →  2 Section Extraction  →  3 Company Context  →  4 LLM Tasks  ⇄  Stylus  →  5 Section Workspace
 (upload)        (find sections in          (figures, risks,      (build packs,           (edit, check,
                  comparables)               relevant pages)       read replies)            export Word)
```

The pages are listed in the left sidebar of the app, in this order.

---

## 4. One-time setup

### 4.1 Start the app
In a command window opened in the project folder, run:
```bash
python -m streamlit run app.py --server.port 8501 --server.headless true --browser.gatherUsageStats false
```
Then open **http://localhost:8501** in the browser. Installation on the office VDI is described in `README.md`.

### 4.2 Register the four presets in Stylus (once per team)
A *preset* is a fixed, shared prompt in Stylus. The tool has four:

| Preset | Purpose |
|---|---|
| **IPO-01 Style & Blueprint** | Learns the structure of the sections from the comparables (optional step). |
| **IPO-02 Draft Our Business** | Writes Our Business. |
| **IPO-03 Draft Risk Factors** | Writes Risk Factors. |
| **IPO-04 Revise Subsection** | Rewrites one subsection based on your instructions. |

To register them:
1. Open **LLM Tasks** and expand **"Stylus presets: register once in Stylus Workspace"**.
2. Copy or download each text, and create a preset with the same name in Stylus.

Preset names include a version, for example *v1.1*. If a version changes, update the text in Stylus.

---

## 5. Step by step

### Step 1 – Deal Setup
1. Expand **Create a new deal** and enter the company name, sector and latest financial year, then click **Create deal**.
2. On the **left**, under *Company documents*:
   - Choose the document type (for example *Annual report*).
   - Upload the PDFs and click **Add company documents**.
   - They become D1, D2, …
3. On the **right**, under *Comparable DRHPs / RHPs*, upload 2–3 prospectuses of similar companies and click **Add comparables**. They become C1, C2, …

Tip: pick comparables from the same sector and business model. Better comparables give a better structure.

### Step 2 – Section Extraction (comparables)
The tool finds where *Our Business* and *Risk Factors* start and end in each comparable.
1. Click **Extract sections**.
2. The tool finds each section like this:
   - It reads the **table of contents** first.
   - It checks that the section really starts with a **bold, capital-letter heading** (for example **OUR BUSINESS**).
   - The section ends just before the next section's bold heading.
3. Check the table:
   - The **Heading check** column shows ✓ when both the start and end headings were confirmed.
   - Anything marked ✗ or with low confidence needs a look.
4. To correct a page range, type the right start and end pages and click **Apply corrections**. Use **"Look at any other page"** to find them.
5. Under **Review an extracted section**, you can see:
   - the start and end page images,
   - the outline of subheadings,
   - the extracted text.

### Step 3 – Company Context (company documents)
1. Click **Process company documents**. The first run can take about a minute per document. The tool:
   - splits two-page spreads into single printed pages and gives each one a label (`D1 p.N`);
   - tags each page by annual-report part (Directors' Report, MD&A, financial statements, …);
   - reads key figures from the financial statements (revenue, profit after tax, net worth, …) and calculates ratios. It uses consolidated figures where available, otherwise standalone;
   - finds **risk triggers**, i.e. signs that a risk applies, such as customer concentration, litigation or falling margins. Each trigger comes with its evidence;
   - matches the relevant pages to each Our Business subsection and each risk theme.
2. Review the four tabs and correct anything that's wrong:

   | Tab | What to check |
   |---|---|
   | **Document parts** | Pages are tagged to the right annual-report part. |
   | **Financial indicators** | Correct any figure, then click **Save figures**. These figures go to Stylus as *verified* numbers. |
   | **Risk triggers** | Tick the triggers that apply, then click **Save trigger selection**. Ticked triggers become **REQUIRED** risks that the draft must cover. |
   | **Pages per subsection** | Add or remove pages for a subsection or risk theme, then click **Save page selection**. |

Note: **Re-process** throws away the edits on this page.

### Step 4 – LLM Tasks (the Stylus round trip)
This page creates the packs and reads the replies.

#### 4a. The blueprint (Step 1 on the page)
The **blueprint** is the outline Stylus follows:
- which Our Business subsections to write, in what order, what each covers and how long it is;
- which Risk Factor themes to cover, in which group.

There are two ways to get one:
- **Use default blueprint**: instant. It gives 15 standard subsections plus risk themes based on your triggers.
- **Create IPO-01 pack**: Stylus learns the outline from your comparables (see §6). You upload the reply, and it replaces the blueprint.

To change the blueprint, open **Review / edit the blueprint**:
- Untick a subsection or theme to leave it out.
- Change titles, target word counts or risk groups.
- Click **Save blueprint**.

Changes only apply to packs you create afterwards.

#### 4b. Draft the sections (Steps 2 and 3 on the page)
- Click **Create IPO-02 pack** for Our Business.
- Click **Create IPO-03 pack** for Risk Factors.

Each pack becomes a task card. Then do the round trip in §6.

### Step 5 – Section Workspace (review and finish)
1. Choose **Our Business** or **Risk Factors**, then a subsection. A status icon shows whether that subsection has problems.
2. **Edit** the heading and text, then click **Save**:
   - Every save keeps the old text in **Version history**, and you can **Restore** any earlier version.
   - Use **Preview** to see the text formatted.
3. Use the right-hand tabs:

   | Tab | What it shows |
   |---|---|
   | **References** | Click a citation to see that page's text, with the numbers used in the draft in bold, or the page image. |
   | **Comparables** | The comparable section, opened at the most similar heading. You can search it. |
   | **Checks** | Problems the tool found (see §8). |

4. To get Stylus to rewrite one subsection:
   - Open **Revise this subsection with Stylus (IPO-04)** and type your instructions, for example *"shorten to 300 words, add the AUM growth table"*.
   - Click **Create IPO-04 pack** and do the round trip with preset IPO-04.
   - The reply replaces **only that subsection**. The old text is kept in Version history.
5. Look at **Gaps to obtain from the company**. These are facts Stylus needed but couldn't find in the documents (marked `[TBD: …]` in the draft). Send them to the company.
6. Switch to **Full section** view and download:
   - **Word (.docx)** of the section,
   - **Markdown**,
   - **CSV** report of all checks.

---

## 6. The Stylus round trip (same for IPO-01, 02, 03 and 04)

1. On the task card, click **⬇ Download pack (.zip)** and unzip it.
2. In Stylus Workspace, open the preset named on the card (for example *IPO-02 Draft Our Business*).
3. Upload **all the PDF files** from the pack in one go, and send.
4. Save Stylus's reply as .docx, .md or .txt, or copy it into a text file.
5. Back on the task card, upload the reply and click **Read reply**. The tool checks:
   - that the reply belongs to this task, using the **TASK_ID** on its first line;
   - that it is in the expected format;
   - that its citations are valid.
6. The draft now appears in the **Section Workspace**.

If the Task ID doesn't match, the reply was meant for a different pack. Make sure you uploaded the reply to the right card.

---

## 7. What is inside a pack

| File | Contents |
|---|---|
| **00_TASK_SHEET** | The instructions for this run: Task ID, deal, blueprint or risk list, verified figures, list of files. |
| **01_SOURCE** | Original pages from the company documents, each stamped `[D1 p.N]`. These are the **only** source of facts. For IPO-01, it holds a few overview pages so Stylus understands the business. |
| **02_STYLE_REF** | Pages from the comparables, stamped **STYLE ONLY**. They are used for structure and tone only. |

Stylus limits and how the tool stays within them:
- **Pages:** Stylus allows 100 pages per run. The tool keeps every pack at **90 pages or fewer**.
- **Size:** Stylus allows 10 MB per run. The tool keeps every pack at **9 MB or less**:
  - First it makes large photos smaller. The text is never changed.
  - Only if that isn't enough does it drop the least important pages. Dropped pages are listed in the Task Sheet.
- The task card shows the pages and MB used.

---

## 8. Checks the tool runs on every draft

| Check | What it means |
|---|---|
| Number not on cited page | A number in the text doesn't appear on the page it cites. Verify it. |
| No citation | A sentence with a number has no `[D… p.…]` reference. |
| Unknown or comparable citation | The text cites a page that wasn't in the pack, or cites a comparable (`C…`) as a source of a fact. |
| Copied from comparable | A sentence is very close to a sentence in a comparable. Rewrite it. |
| Mitigation language (Risk Factors) | SEBI does not allow wording like "we believe this risk is low" in risk factors. |
| Heading form (Risk Factors) | Each risk heading should be a full sentence describing the risk. |
| [TBD] | A fact still needs to be obtained from the company. |
| Required risk not covered | A risk trigger you ticked on page 3 has no risk factor. |

---

## 9. Common questions

**Do I have to run IPO-01?**
No. The default blueprint works. IPO-01 is useful when the comparables have an unusual structure that you want to follow.

**I edited the blueprint after drafting. Does the draft change?**
No. Create a new IPO-02 or IPO-03 pack to redraft with the new blueprint.

**A figure on page 3 was wrong.**
Correct it, click **Save figures**, and create the pack again. Packs made earlier still contain the old figure.

**Stylus says the upload is too large.**
Create the pack again, because packs made before the size check could be over 10 MB. Look at the MB bar on the task card.

**The Section Extraction page shows ✗ in the Heading check.**
The bold capital heading wasn't found where the table of contents pointed. Open the page images, find the correct page, and type it in.

**Where is my data stored?**
In the `data/` folder on the machine running the app. Nothing is sent anywhere except the packs you upload to Stylus yourself.

---

## 10. Glossary

| Term | Meaning |
|---|---|
| DRHP / RHP | Draft Red Herring Prospectus / Red Herring Prospectus |
| Comparable | Prospectus of a similar listed company, used as a style reference |
| Blueprint | The outline (subsections and risk themes) that Stylus follows |
| Pack | The set of PDFs (Task Sheet, Source, Style Ref) you upload to Stylus |
| Preset | A fixed, shared prompt registered in Stylus Workspace |
| Task ID | A unique code for each pack (for example `IPO02-20261119-…`) that links the reply to its pack |
| Risk trigger | Evidence in the company documents that a particular risk applies |
| Printed page | The page number printed on the document, used in citations |
